/*function eje1(){
    let num = parseInt(prompt("Ingresar Numero "))

    if(isNaN(num)){ //no es un numero isNotANumber() (5) -> false, 5 si es un numero / ("hola") -> true, es un string
        console.log("Dato invalido")
        return //te saca del algoritmo y no continua
    }

    if (num > 0) {
        console.log("Es positivo")
        
    }else{
        if(num < 0){
            console.log ("Es negativo")
        }else{
            console.log("Es cero")

        }
    }
    
}*/

/*function ejercicio2() {
    let edad = parseInt(prompt("Ingresar su edad"))
    if (isNaN(edad)) {
        console.log(" Edad Invalida")
        return;
    } else {
        if (edad >= 18) {
            console.log("Es Mayor de Edad")
        } else {
            console.log("Es menor de Edad")
        }

    }
}*/
/*function eje3() {
    let temp = parseFloat(prompt("Ingresar Temperatura"))

     if(isNaN(temp)){ //no es un numero isNotANumber() (5) -> false, 5 si es un numero / ("hola") -> true, es un string
        console.log("Dato invalido")
        return; //te saca del algoritmo y no continua
    }
    if (temp >= 35) {
        console.log("Clima Extremo")
    } else {
        if (temp <= 34 && temp >=25) {
            console.log("Clima Caluroso")
        } else {
            if (temp <= 24 && temp >=15) {
                console.log("Clima Templado")
            } else {
                if (temp <= 14 && temp >=0) {
                    console.log("Clima Frio")
                } else {
                    if (temp < 0) {
                        console.log("Clima Helado")
                    }

                }

            }

        }
    }
}*/

/*function eje4() {
    let usuario = prompt("Ingresar Usuario")
    let contra = prompt("Ingresar Contraseña")
    if (!usuario || !contra) {
        console.log("Usuario no encontrado")
        return;
    }
    if (usuario === admin) {
        if (contra === "1234")
            console.log("Bienvenido")
    } else {
        console.log("usuario incorrecto")
    } else {
            console.log("Contraseña incorrecta")
        }
    }*/
function eje5() {
    let edad = parseInt(prompt("Ingresar Edad"))
    let ingresos = parseFloat(prompt("Ingresar Ingresos"))
    let trabajo = parseFloat(prompt("Ingresar Tiene trabajo?\n1 - SI \n2 - No"))
    if (isNaN(edad) || isNaN(ingresos) || isNaN(trabajo)) {
        console.log("Datos invalidos")
        return
    }
    if (trabajo !== 1 && trabajo !== 2) {
        console.log("Opcion no valida")
        return
    }

    let Tienetrabajo
    if (trabajo === 1) {
        Tienetrabajo = true

    } else {
        Tienetrabajo = false
    }
    if (edad >= 18) {
        if (ingresos > 15000) {
            console.log("Prestamo Aprobado")
        } else {
            if (Tienetrabajo) {
                console.log("Prestamo aprobado")
            }
            else {
                console.log("prestamo denegado,no tiene trabajo ni ingresos")
            }
        }
    } else {
        console.log("Prestamo denegado,es menor de edad")
    }
}

function eje6() {
    let monto = parseFloat(prompt("Ingrese monto de la compra"))
    let pago = parseInt = (prompt("Forma de pago\n1 - Efectivo \n2 - Tarjeta"))
    if (isNaN(monto) || monto <= 0 || isNaN(pago)) {
        console.log("datos invalidos")
        return;
    }
    if (pago !== 1 && pago !== 2) {
        console.log("datos invalidos")
    }

    let total = monto

    if (monto > 10000) {
        if (pago === 1) {
            total = monto * 0.8
        } else {
            total = monto * 0.9
        }
    }
    console.log("Total a Pagar:" Math.round(total))
}

