/*function eje1(){
    let num = parseInt(prompt("Ingresar Numero "))

    if(isNaN(num)){ //no es un numero isNotANumber() (5) -> false, 5 si es un numero / ("hola") -> true, es un string
        console.log("Dato invalido")
        return //te saca del algoritmo y no continua
    }

    if (num > 0) {
        console.log("Es positivo")
        
    }else{
        if(num < 0){
            console.log ("Es negativo")
        }else{
            console.log("Es cero")

        }
    }
    
}*/

/*function ejercicio2() {
    let edad = parseInt(prompt("Ingresar su edad"))
    if (isNaN(edad)) {
        console.log(" Edad Invalida")
        return;
    } else {
        if (edad >= 18) {
            console.log("Es Mayor de Edad")
        } else {
            console.log("Es menor de Edad")
        }

    }
}*/
/*function eje3() {
    let temp = parseFloat(prompt("Ingresar Temperatura"))

     if(isNaN(temp)){ //no es un numero isNotANumber() (5) -> false, 5 si es un numero / ("hola") -> true, es un string
        console.log("Dato invalido")
        return; //te saca del algoritmo y no continua
    }
    if (temp >= 35) {
        console.log("Clima Extremo")
    } else {
        if (temp <= 34 && temp >=25) {
            console.log("Clima Caluroso")
        } else {
            if (temp <= 24 && temp >=15) {
                console.log("Clima Templado")
            } else {
                if (temp <= 14 && temp >=0) {
                    console.log("Clima Frio")
                } else {
                    if (temp < 0) {
                        console.log("Clima Helado")
                    }

                }

            }

        }
    }
}*/

/*function eje4() {
    let usuario = prompt("Ingresar Usuario")
    let contra = prompt("Ingresar Contraseña")
    if (!usuario || !contra) {
        console.log("Usuario no encontrado")
        return;
    }
    if (usuario === admin) {
        if (contra === "1234")
            console.log("Bienvenido")
    } else {
        console.log("usuario incorrecto")
    } else {
            console.log("Contraseña incorrecta")
        }
    }*/
function eje5() {
    let edad = parseInt(prompt("Ingresar Edad"))
    let ingresos = parseFloat(prompt("Ingresar Ingresos"))
    let trabajo = parseFloat(prompt("Ingresar Tiene trabajo?\n1 - SI \n2 - No"))
    if (isNaN(edad) || isNaN(ingresos) || isNaN(trabajo)) {
        console.log("Datos invalidos")
        return
    }
    if (trabajo !== 1 && trabajo !== 2) {
        console.log("Opcion no valida")
        return
    }

    let Tienetrabajo
    if (trabajo === 1) {
        Tienetrabajo = true

    } else {
        Tienetrabajo = false
    }
    if (edad >= 18) {
        if (ingresos > 15000) {
            console.log("Prestamo Aprobado")
        } else {
            if (Tienetrabajo) {
                console.log("Prestamo aprobado")
            }
            else {
                console.log("prestamo denegado,no tiene trabajo ni ingresos")
            }
        }
    } else {
        console.log("Prestamo denegado,es menor de edad")
    }
}

/*function eje6() {
    let monto = parseFloat(prompt("Ingrese monto de la compra"))
    let pago = parseInt = (prompt("Forma de pago\n1 - Efectivo \n2 - Tarjeta"))
    if (isNaN(monto) || monto <= 0 || isNaN(pago)) {
        console.log("datos invalidos")
        return;
    }
    if (pago !== 1 && pago !== 2) {
        console.log("datos invalidos")
    }

    let total = monto

    if (monto > 10000) {
        if (pago === 1) {
            total = monto * 0.8
        } else {
            total = monto * 0.9
        }
    }
    console.log("Total a Pagar:" Math.round(total))
}*/
function eje7() {
    let precioBase = parseFloat(prompt("Ingrese precio"))
    let EsSocio = parseInt(prompt("Sos Socio?\n1 - Si \n2 - No"))
    let cantidadItems = parseInt(prompt("Ingrese cantidad de items"))
    if (isNaN(precioBase) || isNaN(EsSocio) || isNaN(cantidadItems)) {
        console.log("Datos invalidos")
        return;
    }
    if (EsSocio !== 1 && EsSocio !== 2) {
        console.log("Datos Invalidos")
        return;
    }
    if (EsSocio === 1) {
        EsSocio = true
        let descu = (precioBase * 0.20)
        let preciosocio = (precioBase - descu)
        console.log("El Precio siendo socio es :", preciosocio)
    } else {
        EsSocio = false
        if (cantidadItems >= 5) {
            let descuento = (precioBase * 0.10)
            let precionosocio = (precioBase - descuento)
            console.log("Precio final con descuento de mas de 5 items", precionosocio)

        } else {
            console.log("Precio Final :", precioBase)
        }
    }
    if (precioBase < 5000) {
        let adicional = (precioBase * 0.5)
        let preciof = (precioBase + adicional)
        console.log("Precio final Es", preciof)
    }
}



function eje72() {
    let precio = parseFloat(prompt("Ingrese precio"))
    let EsSocio = parseInt(prompt("Sos Socio?\n1 - Si \n2 - No"))
    let cantidadItems = parseInt(prompt("Ingrese cantidad de items"))
    if (isNaN(precioBase) || isNaN(EsSocio) || isNaN(cantidadItems)) {
        console.log("Datos invalidos")
        return;
    }
    if (EsSocio !== 1 && EsSocio !== 2) {
        console.log("Datos Invalidos")
        return;
    }
    if (EsSocio === 1) {
        EsSocio = true

    } else {
        EsSocio = false
    }

    let precioriginal = precio
    let total = precio
    if (EsSocio) {
        total = precio * 0.8
    } else {
        if (cantidadItems >= 0.5) {
            total = precio * 0.9
        }
    }
    if (total > 5000) {
        total = total * 0.95
    }
    let ahorro = precioriginal - total
    console.log("precio original", precioriginal)
    console.log("ahorro", Math.round(ahorro))
    console.log("precio final", Math.round(total))
}


function eje8(){
  let zona = parseInt(prompt("Zona \n1 - CABA \n2 -GBA  \n3 -Interior"))
   let peso= parseFloat(prompt("Peso en kg"))
    let urgente = parseInt(prompt("Envio urgente?\n1 - Si \n2 - No"))
     let miembro = parseInt(prompt("Sos miembro?\n1 - Si \n2 - No"))
      let totalcompra = parseFloat(prompt("Total de compra"))

if (isNaN(zona) || isNaN(peso) || isNaN(urgente) ||isNaN(miembro) || isNaN(totalcompra)){
console.log("Invalido")
return;

//cuando no hay rangos  puede usar switch
//si hay rangos se usa switch
//break sale del switch
//return sale de la funcion
/*switch(zona){
case 1:
    costo=500
    break;
    case 2:
        costo=900;
        break;
    case 3 :
        costo=1500;
        break;
        default
        console.log("Zona invalida")
        return     no puede ser necesario     
        }
*/
}
}
function eje9 (){
let Defectuosos= parseInt(prompt("Sos Socio?\n1 - Si \n2 - No"))
let Producidos = parseInt(prompt("Ingrese cantidad de items"))
    if (isNaN(precioBase) || isNaN(EsSocio) || isNaN(cantidadItems)) {
        console.log("Datos invalidos")
        return;
        if (EsSocio !== 1 && EsSocio !== 2) {
        console.log("Datos Invalidos")
        return;
let Grado;
    if (defectuosos<200) {
        if(producidos>10000){
            console.log("Grado8")
        }
    } else {
console.log("Grado 6")        
    }else{

    }
}